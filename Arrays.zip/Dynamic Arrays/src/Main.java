public class Main{
    public static void main(String args[]){
        DynamicArray array = new DynamicArray();
        
        long start1 = System.currentTimeMillis();
        for(int i = 0; i<1000; i++) {
        	array.addElement(1);
        	array.addElement(2);
        	array.addElement(3);
        	array.addElement(4);
        	array.addElement(5);
        	array.addElement(6);
        	array.addElement(7);
        	array.addElement(8);
        	array.addElement(9);
        	array.addElement(10);
        }
        long end1 = System.currentTimeMillis();
    	System.out.println("Tiempo de creacion: "+ (end1-start1));
    	
    	long start2 = System.currentTimeMillis();
    	array.remove(5);
        long end2 = System.currentTimeMillis();
        System.out.println("Tiempo de eliminacion: "+ (end2-start2));
    	
    	long start3 = System.currentTimeMillis();
    	array.printElements();
        long end3= System.currentTimeMillis();
        System.out.println("Tiempo para imprimir: "+ (end3-start3));
        
        long start4 = System.currentTimeMillis();
    	int num = array.getElement(5);
    	System.out.println("Dato en posicion dada es: "+ num);
        long end4= System.currentTimeMillis();
        System.out.println("Tiempo para encontrar un dato: "+ (end4-start4));
        
        long start5 = System.currentTimeMillis();
        array.addElement(5,99);
        long end5= System.currentTimeMillis();
        System.out.println("Tiempo para actualizar: "+ (end5-start5));
        
    }
}