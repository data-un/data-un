import java.util.Arrays;
public class DynamicArray{
    private int array[];
    
    private int size;
    
    private int capacity;
     
    // GENERAR EL ARRAY
    public DynamicArray(){
        array = new int[2];
        size=0;
        capacity=2;
    }
     
    // AGREGAR DATO AL FINAL
    public void addElement(int element){
        // Duplicar la capacidad si se llena
        if (size == capacity){
            ensureCapacity(2); 
        }
        array[size] = element;
        size++;
    }
     
    // AGREGAR DATO EN POSICION ESPECIFICA
    
    public void addElement(int index, int element){
        // Duplicar la capacidad si se llena
        if (size == capacity){
            ensureCapacity(2); 
        }
        // Correr los elementos a la derecha
        for(int i=size-1;i>=index;i--){
            array[i+1] = array[i];
        }
        // Insertar elemento
        array[index] = element;
        size++;
    }
 
    // ENCONTRAR DATO DADA LA POSICION
    public int getElement(int index){
        return array[index];
    }
     
    // ELIMINAR DATO EN POSICION ESPECIFICA
    public void remove(int index){
        if(index>=size || index<0){
            System.out.println("No hay elemento en esta posicion");
        }else{
            for(int i=index;i<size-1;i++){
                array[i] = array[i+1];
            }
            array[size-1]=0;
            size--;
        }
    }
     
    //METODO PARA AUMENTAR CAPACIDAD
    
    public void ensureCapacity(int minCapacity){
        int temp[] = new int[capacity*minCapacity];
        for (int i=0; i < capacity; i++){
            temp[i] = array[i];
        }
        array = temp;
        capacity = capacity * minCapacity;
    }
     
    //METODO PARA BAJAR CAPACIDAD NO UTILIZADA
    
    public void trimToSize(){
        System.out.println("Recortando arreglo");
        int temp[] = new int[size];
        for (int i=0; i < size; i++){
            temp[i] = array[i];
        }
        array = temp;
        capacity = array.length;
         
    }
     
    // MOSTRAR TAMANO
    public int size(){
        return size;
    }
     
    // MOSTRAR CAPACIDAD
    public int capacity(){
        return capacity;
    }
     
    // IMPRIMIR TODO EL ARREGLO
    public void printElements(){
        System.out.println("Arreglo :"+Arrays.toString(array));
    }
}