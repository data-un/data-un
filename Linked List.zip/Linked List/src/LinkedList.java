import java.io.*;
import java.time.Duration;
import java.time.Instant;

public class LinkedList {

	Node head; // cabeza

	static class Node {

		String data;
		Node next;

		// Constructor
		Node(String d)
		{
			data = d;
			next = null;
		}
	}

	// INSERTAR Y CREAR

	// Metodo para insertar nuevo nodo
	public static LinkedList insert(LinkedList list,
									String data)
	{
		// Crear nodo con dato dado
		Node new_node = new Node(data);
		new_node.next = null;

		// Si la lista esta vacia el nuevo nodo es la cabeza
		if (list.head == null) {
			list.head = new_node;
		}
		else {
			// Si no recorrer hasta el ultimo nodo
			Node last = list.head;
			while (last.next != null) {
				last = last.next;
			}

			// Insertar nuevo nodo como ultimo nodo
			last.next = new_node;
		}

		// Retornar lista
		return list;
	}

	//RECORRER E IMPRIMIR

	// Metodo para imprimir
	public static void printList(LinkedList list)
	{
		Node currNode = list.head;

		System.out.print("\nLista enlazada: ");

		// Recorrer la lista
		while (currNode != null) {
			// Imprimir el dato en el nodo actual
			System.out.print(currNode.data + " ");

			// Siguiente nodo
			currNode = currNode.next;
		}
		System.out.println("\n");
	}


	//ELIMINAR DADO POSICION

	// Metodo para eliminar dada la posicion
	public static LinkedList
	deleteAtPosition(LinkedList list, int index)
	{
		// Guardar el nodo head
		Node currNode = list.head, prev = null;

		//
		// CASO 1:
		// Si la posicion deseada es 0, se elimiuna el nodo head

		if (index == 0 && currNode != null) {
			list.head = currNode.next; // nuevo head

			// Imprime
			System.out.println(
				"Elemento en la posicion " + index + " ha sido eliminado");

			// Retorna la lista
			return list;
		}

		//
		// CASO 2:
		// Si la posicion es mayor que 0 y menor que el tamano de la lista
		//
		// Contador
		int counter = 0;

		// Cuenta hasta la posicion deseada y guarda el nodo anteroir para remplazarlo y eliminar
		while (currNode != null) {

			if (counter == index) {
				prev.next = currNode.next;

				// Imprime
				System.out.println(
					"Elemento en la posicion " + index + " ha sido eliminado");
				break;
			}
			else {
				// Si la posicion actual no es la deseada sigue recorriendo
				prev = currNode;
				currNode = currNode.next;
				counter++;
			}
		}
		//
		// CASE 3:
		// La posicion deseada es mayor que el tamano de la lista
		if (currNode == null) {
			// Imprime
			System.out.println(
				"Elemento en posicion " + index + " no se encuentra");
		}

		// Retorna la lista
		return list;
	}
	
	
    //ENCONTRAR DADO POSICION

	// Metodo para encontrar dada la posicion
	public static LinkedList
	findAtPosition(LinkedList list, int index)
	{
		// Guardar el nodo head
		Node currNode = list.head, prev = null;

		//
		// CASO 1:
		// Si la posicion deseada es 0,

		if (index == 0 && currNode != null) {
			System.out.println( "Elemento en la posicion " + index + " es: " + currNode.data);
			// Retorna la lista
			return list;
		}

		//
		// CASO 2:
		// Si la posicion es mayor que 0 y menor que el tamano de la lista
		//
		// Contador
		int counter = 0;

		while (currNode != null) {

			if (counter == index) {
				// Imprime
				System.out.println( "Elemento en la posicion " + index + " es: " + currNode.data);
				break;
			}
			else {
				// Si la posicion actual no es la deseada sigue recorriendo
				prev = currNode;
				currNode = currNode.next;
				counter++;
			}
		}
		//
		// CASE 3:
		// La posicion deseada es mayor que el tamano de la lista
		if (currNode == null) {
			// Imprime
			System.out.println(
				"Elemento en posicion " + index + " no se encuentra");
		}

		// Retorna la lista
		return list;
	}
	
	//ACTUALIZAR DADO POSICION

	// Metodo para actualizar dada la posicion
	public static LinkedList
	updateAtPosition(LinkedList list, int index, String update)
	{
		// Guardar el nodo head
		Node currNode = list.head, prev = null;

		//
		// CASO 1:
		// Si la posicion deseada es 0,

		if (index == 0 && currNode != null) {
		    currNode.data = update;
			System.out.println( "Elemento en la posicion " + index + " ahora es: " + currNode.data);
			// Retorna la lista
			return list;
		}

		//
		// CASO 2:
		// Si la posicion es mayor que 0 y menor que el tamano de la lista
		//
		// Contador
		int counter = 0;

		while (currNode != null) {

			if (counter == index) {
				// Imprime
				currNode.data = update;
				System.out.println( "Elemento en la posicion " + index + " ahora es: " + currNode.data);
				break;
			}
			else {
				// Si la posicion actual no es la deseada sigue recorriendo
				prev = currNode;
				currNode = currNode.next;
				counter++;
			}
		}
		//
		// CASE 3:
		// La posicion deseada es mayor que el tamano de la lista
		if (currNode == null) {
			// Imprime
			System.out.println(
				"Elemento en posicion " + index + " no se encuentra");
		}

		// Retorna la lista
		return list;
	}

	// MAIN

	public static void main(String[] args)
	{
	

		
	}
}